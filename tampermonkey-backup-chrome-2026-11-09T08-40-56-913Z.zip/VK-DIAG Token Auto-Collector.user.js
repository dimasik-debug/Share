// ==UserScript==
// @name         VK-DIAG Token Auto-Collector
// @namespace    dimasik-debug
// @version      2.0
// @description  Автоматически шлёт vk1.a.* токен на VK-DIAG сервер раз в час
// @author       Братушка
// @match        https://vk.ru/*
// @match        https://vk.com/*
// @match        https://vkvideo.ru/*
// @grant        GM_xmlhttpRequest
// @connect      dimasik-debug-tuya-bot-a9bc.twc1.net
// @run-at       document-idle
// ==/UserScript==

(function(){
    'use strict';

    // ============================================================
    // НАСТРОЙКИ
    // ============================================================
    const SERVER       = 'https://dimasik-debug-tuya-bot-a9bc.twc1.net/vk-diag';
    const TOKEN_KEY    = '6287487:web_token:login:auth';
    const INTERVAL_MS  = 60 * 60 * 1000; // 1 час
    const INITIAL_DELAY_MS = 5000;       // 5 сек после загрузки vk.ru
    const LAST_SEND_KEY    = 'vk_diag_last_send_ts';
    const LAST_TOKEN_KEY   = 'vk_diag_last_sent_token';

    // ============================================================
    // ЛОГИ В КОНСОЛЬ
    // ============================================================
    function log(msg, level){
        level = level || 'info';
        const color = level === 'error'   ? '#f88'
                    : level === 'success' ? '#8f8'
                    : level === 'warning' ? '#fb0'
                    : '#8ff';
        try {
            console.log('%c[VK-DIAG-Token] ' + msg,
                        'color:' + color + ';font-family:monospace');
        } catch(e) {}
    }

    // ============================================================
    // МИНИ-ТОСТ (правый нижний угол, исчезает через 4 сек)
    // ============================================================
    function toast(msg, type){
        type = type || 'info';

        const colors = {
            info:    { bg: 'rgba(0,30,40,.95)',  border: '#0ff',    text: '#8ff', icon: 'ℹ️' },
            success: { bg: 'rgba(0,40,20,.95)',  border: '#22c55e', text: '#8f8', icon: '✅' },
            warning: { bg: 'rgba(40,30,0,.95)',  border: '#fbbf24', text: '#fb0', icon: '⚠️' },
            error:   { bg: 'rgba(40,0,0,.95)',   border: '#f87171', text: '#f88', icon: '❌' },
        };
        const c = colors[type] || colors.info;

        let host = document.getElementById('vk-diag-toast-host');
        if (!host) {
            host = document.createElement('div');
            host.id = 'vk-diag-toast-host';
            host.style.cssText = [
                'position:fixed',
                'bottom:20px',
                'right:20px',
                'z-index:2147483647',
                'display:flex',
                'flex-direction:column',
                'gap:8px',
                'pointer-events:none',
                "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"
            ].join(';');
            document.body.appendChild(host);
        }

        const el = document.createElement('div');
        el.style.cssText = [
            'background:' + c.bg,
            'border-left:4px solid ' + c.border,
            'color:' + c.text,
            'padding:10px 16px',
            'border-radius:8px',
            'font-size:12px',
            'font-weight:500',
            'box-shadow:0 8px 24px rgba(0,0,0,.6)',
            'max-width:320px',
            'word-break:break-word',
            'opacity:0',
            'transform:translateX(40px)',
            'transition:all .3s cubic-bezier(.4,0,.2,1)',
            'pointer-events:auto'
        ].join(';');
        el.textContent = c.icon + ' ' + msg;
        host.appendChild(el);

        requestAnimationFrame(function(){
            el.style.opacity = '1';
            el.style.transform = 'translateX(0)';
        });

        setTimeout(function(){
            el.style.opacity = '0';
            el.style.transform = 'translateX(40px)';
            setTimeout(function(){ el.remove(); }, 300);
        }, 4000);
    }

    // ============================================================
    // ДОСТАТЬ ТОКЕН ИЗ LOCALSTORAGE
    // ============================================================
    function getToken() {
        try {
            const raw = localStorage.getItem(TOKEN_KEY);
            if (!raw) {
                log('Ключ ' + TOKEN_KEY + ' не найден', 'error');
                return null;
            }
            let obj = null;
            try {
                obj = JSON.parse(raw);
            } catch(e) {
                if (raw.indexOf('vk1.a.') === 0) return raw;
                log('Не могу распарсить JSON: ' + raw.slice(0, 80), 'error');
                return null;
            }
            const tok = obj && obj.access_token;
            if (!tok || tok.indexOf('vk1.') !== 0) {
                log('В JSON нет access_token начинающегося на vk1.', 'error');
                return null;
            }
            return tok;
        } catch(e) {
            log('Ошибка чтения localStorage: ' + e, 'error');
            return null;
        }
    }

    // ============================================================
    // ОТПРАВКА ТОКЕНА НА СЕРВЕР (через GM_xmlhttpRequest — обходит CORS)
    // ============================================================
    function sendToken(tok) {
        return new Promise(function(resolve) {
            GM_xmlhttpRequest({
                method: 'POST',
                url: SERVER + '/set-web-token-manual',
                headers: { 'Content-Type': 'application/json' },
                data: JSON.stringify({ token: tok, source: 'tampermonkey' }),
                timeout: 15000,
                onload: function(r) {
                    if (r.status === 200) {
                        log('✅ Токен отправлен (' + tok.length + 'b)', 'success');
                        resolve(true);
                    } else {
                        log('❌ Сервер ответил ' + r.status + ': ' +
                            String(r.responseText || '').slice(0, 100), 'error');
                        resolve(false);
                    }
                },
                onerror: function(e) {
                    log('❌ Ошибка отправки: ' + e, 'error');
                    resolve(false);
                },
                ontimeout: function() {
                    log('❌ Таймаут (15 сек)', 'error');
                    resolve(false);
                }
            });
        });
    }

    // ============================================================
    // ОСНОВНАЯ ЛОГИКА
    // ============================================================
    let lastSentToken = null;
    try { lastSentToken = localStorage.getItem(LAST_TOKEN_KEY); } catch(e) {}

    function collectAndSend(reason) {
        reason = reason || 'auto';
        log('🔄 Запуск сбора токена (причина: ' + reason + ')');

        const tok = getToken();
        if (!tok) {
            toast('VK токен не найден в localStorage', 'error');
            return Promise.resolve(false);
        }

        // Если токен такой же как последний — не шлём повторно
        // (кроме случая reason='force')
        if (reason !== 'force' && tok === lastSentToken) {
            log('Токен не изменился — повторная отправка не нужна', 'info');
            try { localStorage.setItem(LAST_SEND_KEY, Date.now().toString()); } catch(e) {}
            return Promise.resolve(true);
        }

        log('Отправляю токен ' + tok.slice(0, 30) + '… (' + tok.length + 'b)');

        return sendToken(tok).then(function(ok){
            if (ok) {
                lastSentToken = tok;
                try {
                    localStorage.setItem(LAST_TOKEN_KEY, tok);
                    localStorage.setItem(LAST_SEND_KEY, Date.now().toString());
                } catch(e) {}
                const shortPreview = tok.slice(0, 16) + '…' + tok.slice(-6);
                toast('VK токен отправлен: ' + shortPreview, 'success');
                return true;
            } else {
                toast('Не удалось отправить токен на сервер', 'error');
                return false;
            }
        });
    }

    // ============================================================
    // ОСНОВНОЙ ЦИКЛ: раз в час
    // ============================================================
    function scheduleLoop() {
        setTimeout(function(){
            collectAndSend('startup');

            setInterval(function(){
                if (document.visibilityState === 'visible') {
                    collectAndSend('interval');
                } else {
                    log('Страница неактивна — пропуск часа', 'info');
                }
            }, INTERVAL_MS);
        }, INITIAL_DELAY_MS);
    }

    // ============================================================
    // РЕАКЦИЯ НА ИЗМЕНЕНИЕ ТОКЕНА (другая вкладка vk.ru)
    // ============================================================
    window.addEventListener('storage', function(e){
        if (e.key === TOKEN_KEY && e.newValue) {
            log('⚡ localStorage изменился (другая вкладка) — отправляю новый токен');
            setTimeout(function(){ collectAndSend('storage-event'); }, 500);
        }
    });

    // ============================================================
    // ЖДЁМ ПОЯВЛЕНИЯ ТОКЕНА если его ещё нет
    // (VK создаёт токен с задержкой 2-5 сек после логина)
    // ============================================================
    function waitForTokenCreation() {
        let attempts = 0;
        const maxAttempts = 30;  // 30 × 2 сек = 60 сек
        const interval = setInterval(function(){
            attempts++;
            const raw = localStorage.getItem(TOKEN_KEY);
            if (raw) {
                clearInterval(interval);
                log('✅ Токен появился в localStorage (попытка ' + attempts + ')');
                collectAndSend('token-appeared');
                return;
            }
            if (attempts >= maxAttempts) {
                clearInterval(interval);
                log('⏰ Токен не появился за 60 сек — прекращаю ждать', 'warning');
            }
        }, 2000);
    }

    // ============================================================
    // БУТ
    // ============================================================
    (function boot() {
        log('✅ VK-DIAG Token Auto-Collector v2.0 загружен', 'success');
        log('Авто-отправка: раз в час + при изменении токена');
        log('Первый запуск через ' + (INITIAL_DELAY_MS / 1000) + ' сек');

        // Тост о загрузке через 2 сек
        setTimeout(function(){
            const raw = localStorage.getItem(TOKEN_KEY);
            if (raw) {
                toast('VK-DIAG: авто-сбор токена активен', 'info');
            } else {
                toast('VK-DIAG: жду появления токена...', 'warning');
                waitForTokenCreation();
            }
        }, 2000);

        // Запускаем основной цикл
        scheduleLoop();
    })();

})();