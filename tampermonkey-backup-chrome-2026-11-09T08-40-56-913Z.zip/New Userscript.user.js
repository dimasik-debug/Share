// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      2026-11-09
// @description  try to take over the world!
// @author       You
// @match        https://chat.deepseek.com/a/chat/s/c1d57b89-8851-4249-93a8-a477e9618b88
// @icon         https://www.google.com/s2/favicons?sz=64&domain=deepseek.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();